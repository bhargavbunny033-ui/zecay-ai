# ZECAY AI

ZECAY AI is a simple AI question-and-answer web app with a clean chat interface.

## What is included

- AI chat
- Telugu / English / Telugu-English response mode
- Quick question buttons
- Voice input in supported browsers
- Image attachment UI
- Responsive desktop/mobile layout
- Secure server-side API key handling
- Chat history during the current session

## Requirements

Install Node.js 18+ (Node.js 20+ recommended).

## Setup

1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal in VS Code.
4. Run:

```bash
npm install
```

5. Copy `.env.example` to `.env`.
6. Open `.env` and put your API key:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-5-mini
PORT=3000
```

7. Start:

```bash
npm start
```

8. Open:

http://localhost:3000

## Important

Never put your API key inside `public/app.js` or any frontend file.
Keep it in `.env` on the server.

The current version sends questions to the OpenAI Responses API. Current web/live search,
image understanding, user accounts, database chat history, payments, and mobile APK packaging
are planned as the next development stage.

## Troubleshooting

If you see "OPENAI_API_KEY is not configured":
- Make sure the file is named `.env`
- Make sure it is in the project root, next to `server.js`
- Restart `npm start`

If `npm` is not recognized:
- Install Node.js
- Restart VS Code
- Run `node --version` and `npm --version`
