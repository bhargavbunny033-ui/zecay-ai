const chat = document.getElementById("chat");
const welcome = document.getElementById("welcome");
const form = document.getElementById("composer");
const input = document.getElementById("message");
const sendBtn = document.getElementById("sendBtn");
const newChat = document.getElementById("newChat");
const language = document.getElementById("language");
const voiceBtn = document.getElementById("voiceBtn");
const imageBtn = document.getElementById("imageBtn");
const imageInput = document.getElementById("imageInput");
const imagePreview = document.getElementById("imagePreview");

let history = [];
let selectedImage = null;

document.querySelectorAll(".quick").forEach(btn => {
  btn.addEventListener("click", () => {
    input.value = btn.textContent.replace(/^[^A-Za-z0-9\u0C00-\u0C7F]+/, "").trim();
    input.focus();
  });
});

newChat.addEventListener("click", () => {
  history = [];
  selectedImage = null;
  imagePreview.classList.add("hidden");
  chat.innerHTML = "";
  chat.appendChild(welcome);
  welcome.style.display = "";
  input.value = "";
});

input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 160) + "px";
});

form.addEventListener("submit", async e => {
  e.preventDefault();
  const message = input.value.trim();
  if (!message) return;

  welcome.style.display = "none";
  addMessage("user", message);
  history.push({ role: "user", content: message });
  input.value = "";
  input.style.height = "auto";
  sendBtn.disabled = true;

  const typing = addMessage("assistant", "Thinking...");
  typing.querySelector(".bubble").classList.add("typing");

  try {
    const languageInstruction = language.value !== "auto"
      ? ` Answer in ${language.value === "tenglish" ? "Telugu written using English letters" : language.value}.`
      : "";

    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: message + languageInstruction,
        history: history.slice(0, -1)
      })
    });

    const data = await response.json();
    typing.remove();

    if (!response.ok) throw new Error(data.error || "Request failed");

    addMessage("assistant", data.answer);
    history.push({ role: "assistant", content: data.answer });
  } catch (err) {
    typing.remove();
    addMessage("assistant", "⚠️ " + err.message);
  } finally {
    sendBtn.disabled = false;
    input.focus();
  }
});

function addMessage(role, text) {
  const row = document.createElement("div");
  row.className = `message-row ${role}`;

  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "You" : "Z";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  row.appendChild(avatar);
  row.appendChild(bubble);
  chat.appendChild(row);
  chat.scrollTop = chat.scrollHeight;
  return row;
}

voiceBtn.addEventListener("click", () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    alert("Voice input is not supported in this browser. Try Chrome.");
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.lang = language.value === "telugu" ? "te-IN" : "en-IN";
  recognition.interimResults = false;
  recognition.onresult = e => {
    input.value = e.results[0][0].transcript;
    input.dispatchEvent(new Event("input"));
  };
  recognition.start();
});

imageBtn.addEventListener("click", () => imageInput.click());

imageInput.addEventListener("change", () => {
  const file = imageInput.files[0];
  if (!file) return;
  selectedImage = file;
  imagePreview.classList.remove("hidden");
  imagePreview.innerHTML = "";
  const img = document.createElement("img");
  img.src = URL.createObjectURL(file);
  imagePreview.appendChild(img);
  // Image upload UI is included in V1. Multimodal API handling can be enabled next.
});