const express = require("express");
const path = require("path");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-5-mini";

app.use(express.json({ limit: "10mb" }));
app.use(express.static(path.join(__dirname, "public")));

const SYSTEM_PROMPT = `
You are ZECAY AI, a helpful and careful AI assistant.
Answer clearly and directly. The user may write English, Telugu, or Telugu in English letters.
Reply in the same language/style as the user unless they request another language.
For financial, stock, mutual-fund, tax, or investment questions, clearly separate facts from opinions,
avoid pretending to know live prices unless current data is supplied, and say when information needs verification.
Do not claim certainty when the information is uncertain or time-sensitive.
Use simple explanations and examples when useful.
`;

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [] } = req.body || {};
    if (!message || !String(message).trim()) {
      return res.status(400).json({ error: "Please enter a question." });
    }

    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({
        error: "OPENAI_API_KEY is not configured. Copy .env.example to .env and add your API key."
      });
    }

    const input = [
      { role: "system", content: SYSTEM_PROMPT },
      ...history.slice(-12).map(item => ({
        role: item.role === "assistant" ? "assistant" : "user",
        content: String(item.content || "")
      })),
      { role: "user", content: String(message) }
    ];

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: MODEL,
        input
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "AI service returned an error."
      });
    }

    const answer = data.output_text || extractOutputText(data);
    return res.json({ answer: answer || "I could not generate an answer." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});

function extractOutputText(data) {
  try {
    return (data.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text)
      .join("\n");
  } catch {
    return "";
  }
}

app.get("*splat", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`ZECAY AI running at http://localhost:${PORT}`);
});